#include<bits/stdc++.h>

int main() {
	std::cout << 1;
}
